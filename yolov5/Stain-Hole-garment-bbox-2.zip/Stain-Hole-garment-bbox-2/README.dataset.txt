# undefined > 2022-05-04 6:51pm sem augmentation
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

undefined