
Stain-Hole-garment-bbox - v2 2022-05-04 6:51pm sem augmentation
==============================

This dataset was exported via roboflow.ai on May 5, 2022 at 8:03 PM GMT

It includes 350 images.
Defects are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


